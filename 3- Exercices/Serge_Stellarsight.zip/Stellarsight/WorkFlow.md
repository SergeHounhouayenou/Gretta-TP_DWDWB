Kronos du projet

## Lunidi 06 Janvier 2025

** Réception des consignes dans la journée pendant les heures de formation et visite du site de la NASA le soir sur le temps libre pour les premiers réglages.

** Conception de l'architecture HTML/CSS du projet le soir sur le temps libre.

## mardi 07 Janvier 2025

** Finition du DOM sur le temps libre en soirée

## mercredi 08 Janvier 2025

** en soirée : implémentation des requetes asynchrones pour les 4 API de la contrainte et réalisation du test de contrôle de base de donnée sur la page d'acceuil pour assurer la faisabilité du projet et identifier les éventuelles difficultées à surmonter.

## jeudi 09 Janvier 2025

** en soirée : implémentation des contrôles d'utilisateur dans les selects des pages du DOM pour activer l'interactivité entre l'utilisateur et la base de donnée des API via le site du projet.

## vendredi 10 Janvier 2025

** en soirée : finition des contrôles d'utilisateur et enrichissement des possibilités d'interacton

## samedi 11 Janvier 2025

** finition esthétique selon le temps libre

## dimanche 12 Janvier 2025

** dernières vérification et envoie du projet
